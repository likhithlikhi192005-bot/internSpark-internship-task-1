#!/usr/bin/env python3
"""
file_automation.py
====================
A command-line file automation tool that can SORT, RENAME, and CLEAN
files in a target directory, with full logging and exception handling.

Standard-library only (os, shutil, argparse, logging, datetime, pathlib).

Usage examples
--------------
Sort files into sub-folders by extension:
    python file_automation.py sort --path ./sample_data

Batch rename files with a prefix + running counter:
    python file_automation.py rename --path ./sample_data --prefix photo_

Clean up empty files and files matching junk patterns (.tmp, .log, ~ etc.):
    python file_automation.py clean --path ./sample_data

Run without CLI args to be prompted interactively:
    python file_automation.py
"""

import os
import sys
import shutil
import logging
import argparse
from datetime import datetime
from pathlib import Path

# --------------------------------------------------------------------------
# Logging setup: every run appends a timestamped entry to file_automation.log
# and also prints INFO+ messages to the console.
# --------------------------------------------------------------------------
LOG_FILE = "file_automation.log"

def setup_logging():
    logger = logging.getLogger("file_automation")
    logger.setLevel(logging.DEBUG)

    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s", "%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_fmt)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_fmt = logging.Formatter("%(levelname)-8s | %(message)s")
    console_handler.setFormatter(console_fmt)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


log = setup_logging()

# Default extension -> folder-name mapping used by the sort operation
CATEGORY_MAP = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
    "Documents": [".pdf", ".doc", ".docx", ".txt", ".md", ".rtf", ".odt"],
    "Spreadsheets": [".xls", ".xlsx", ".csv"],
    "Presentations": [".ppt", ".pptx"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
    "Audio": [".mp3", ".wav", ".flac", ".aac"],
    "Video": [".mp4", ".mov", ".avi", ".mkv"],
    "Code": [".py", ".js", ".html", ".css", ".java", ".cpp", ".c", ".json"],
}

JUNK_PATTERNS = (".tmp", ".log", ".bak", "~", ".DS_Store")


def _category_for_extension(ext):
    ext = ext.lower()
    for category, extensions in CATEGORY_MAP.items():
        if ext in extensions:
            return category
    return "Other"


def validate_directory(path):
    """Confirm the path exists and is a directory; raise otherwise."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Path does not exist: {path}")
    if not os.path.isdir(path):
        raise NotADirectoryError(f"Path is not a directory: {path}")
    return True


# --------------------------------------------------------------------------
# OPERATION 1: SORT — move files into category sub-folders by extension
# --------------------------------------------------------------------------
def sort_files(path):
    validate_directory(path)
    moved, skipped, errors = 0, 0, 0

    entries = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    log.info(f"Starting SORT on '{path}' ({len(entries)} file(s) found)")

    for filename in entries:
        src = os.path.join(path, filename)
        _, ext = os.path.splitext(filename)

        if not ext:
            log.debug(f"Skipping '{filename}': no extension")
            skipped += 1
            continue

        category = _category_for_extension(ext)
        dest_dir = os.path.join(path, category)

        try:
            os.makedirs(dest_dir, exist_ok=True)
            dest = os.path.join(dest_dir, filename)

            # Avoid overwriting an existing file with the same name
            if os.path.exists(dest):
                base, extension = os.path.splitext(filename)
                dest = os.path.join(dest_dir, f"{base}_dup{extension}")
                log.warning(f"Duplicate name detected, renaming to '{os.path.basename(dest)}'")

            shutil.move(src, dest)
            log.info(f"Moved '{filename}' -> {category}/")
            moved += 1

        except PermissionError as e:
            log.error(f"Permission denied moving '{filename}': {e}")
            errors += 1
        except OSError as e:
            log.error(f"OS error moving '{filename}': {e}")
            errors += 1

    log.info(f"SORT complete: {moved} moved, {skipped} skipped, {errors} errors")
    return {"moved": moved, "skipped": skipped, "errors": errors}


# --------------------------------------------------------------------------
# OPERATION 2: RENAME — batch rename files with prefix + zero-padded counter
# --------------------------------------------------------------------------
def rename_files(path, prefix="file_", start=1):
    validate_directory(path)
    renamed, errors = 0, 0

    entries = sorted(f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f)))
    log.info(f"Starting RENAME on '{path}' ({len(entries)} file(s) found), prefix='{prefix}'")

    counter = start
    for filename in entries:
        src = os.path.join(path, filename)
        _, ext = os.path.splitext(filename)
        new_name = f"{prefix}{counter:03d}{ext}"
        dest = os.path.join(path, new_name)

        try:
            if os.path.exists(dest):
                raise FileExistsError(f"Target name already exists: {new_name}")
            os.rename(src, dest)
            log.info(f"Renamed '{filename}' -> '{new_name}'")
            renamed += 1
            counter += 1
        except FileExistsError as e:
            log.error(str(e))
            errors += 1
        except OSError as e:
            log.error(f"OS error renaming '{filename}': {e}")
            errors += 1

    log.info(f"RENAME complete: {renamed} renamed, {errors} errors")
    return {"renamed": renamed, "errors": errors}


# --------------------------------------------------------------------------
# OPERATION 3: CLEAN — remove empty files and junk/temp files
# --------------------------------------------------------------------------
def clean_files(path):
    validate_directory(path)
    removed, errors = 0, 0

    entries = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    log.info(f"Starting CLEAN on '{path}' ({len(entries)} file(s) found)")

    for filename in entries:
        full_path = os.path.join(path, filename)
        is_junk = filename.endswith(JUNK_PATTERNS)

        try:
            is_empty = os.path.getsize(full_path) == 0
        except OSError as e:
            log.error(f"Could not stat '{filename}': {e}")
            errors += 1
            continue

        if is_junk or is_empty:
            try:
                os.remove(full_path)
                reason = "junk pattern" if is_junk else "empty file"
                log.info(f"Removed '{filename}' ({reason})")
                removed += 1
            except PermissionError as e:
                log.error(f"Permission denied removing '{filename}': {e}")
                errors += 1
            except OSError as e:
                log.error(f"OS error removing '{filename}': {e}")
                errors += 1

    log.info(f"CLEAN complete: {removed} removed, {errors} errors")
    return {"removed": removed, "errors": errors}


# --------------------------------------------------------------------------
# Interactive mode (used when the script is run with no CLI arguments)
# --------------------------------------------------------------------------
def interactive_mode():
    print("=== File Automation Tool (interactive mode) ===")
    op = input("Choose operation [sort/rename/clean]: ").strip().lower()
    path = input("Target directory path: ").strip()

    try:
        if op == "sort":
            sort_files(path)
        elif op == "rename":
            prefix = input("Filename prefix (default 'file_'): ").strip() or "file_"
            rename_files(path, prefix=prefix)
        elif op == "clean":
            clean_files(path)
        else:
            log.error(f"Unknown operation: '{op}'")
    except (FileNotFoundError, NotADirectoryError) as e:
        log.error(str(e))


# --------------------------------------------------------------------------
# CLI entry point
# --------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        description="Automate sorting, renaming, and cleaning files in a directory."
    )
    subparsers = parser.add_subparsers(dest="command")

    sort_p = subparsers.add_parser("sort", help="Sort files into category folders")
    sort_p.add_argument("--path", required=True, help="Target directory")

    rename_p = subparsers.add_parser("rename", help="Batch rename files")
    rename_p.add_argument("--path", required=True, help="Target directory")
    rename_p.add_argument("--prefix", default="file_", help="Filename prefix")
    rename_p.add_argument("--start", type=int, default=1, help="Starting counter value")

    clean_p = subparsers.add_parser("clean", help="Remove empty/junk files")
    clean_p.add_argument("--path", required=True, help="Target directory")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    log.info(f"Session started ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})")

    if args.command is None:
        interactive_mode()
        return

    try:
        if args.command == "sort":
            sort_files(args.path)
        elif args.command == "rename":
            rename_files(args.path, prefix=args.prefix, start=args.start)
        elif args.command == "clean":
            clean_files(args.path)
    except (FileNotFoundError, NotADirectoryError) as e:
        log.error(str(e))
        sys.exit(1)
    except Exception as e:  # final safety net so the tool never crashes silently
        log.error(f"Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
