# File Automation Tool

A standard-library-only Python CLI for automating common file-organization
tasks: **sort**, **rename**, and **clean**. Built with `os`/`shutil` for
filesystem work, `logging` for a full audit trail, and `argparse` for
CLI input (with an interactive fallback prompt).

## Features

- **sort** — moves files into category sub-folders (`Images/`, `Documents/`,
  `Spreadsheets/`, `Code/`, etc.) based on file extension
- **rename** — batch renames files with a custom prefix and zero-padded counter
- **clean** — removes empty files and junk files (`.tmp`, `.log`, `.bak`, `~`)
- Every operation is logged to both the console and `file_automation.log`
  with timestamps and severity levels
- Full exception handling for missing paths, permission errors, duplicate
  names, and other OS-level failures — the tool never crashes silently
- Works via CLI flags **or** interactive prompts if run with no arguments

## Requirements

- Python 3.7+
- No third-party dependencies (standard library only: `os`, `shutil`,
  `argparse`, `logging`, `datetime`, `pathlib`, `sys`)

## Usage

```bash
# Sort files in a directory into category sub-folders
python file_automation.py sort --path ./sample_data

# Batch rename files with a prefix (default counter starts at 1)
python file_automation.py rename --path ./sample_data --prefix photo_ --start 1

# Remove empty files and junk files (.tmp, .log, .bak, ~)
python file_automation.py clean --path ./sample_data

# No arguments -> interactive mode, prompts for operation and path
python file_automation.py
```

## Sample Input

Starting directory `sample_data/`:

```
archive.zip
beach.png
budget.xlsx
cache.tmp            <- junk file
empty_placeholder.txt <- empty file
notes.txt
old_run.log          <- junk file
resume.docx
script.py
song.mp3
vacation.jpg
```

## Sample Run

```bash
$ python file_automation.py clean --path ./sample_data
INFO     | Starting CLEAN on './sample_data' (11 file(s) found)
INFO     | Removed 'empty_placeholder.txt' (empty file)
INFO     | Removed 'old_run.log' (junk pattern)
INFO     | Removed 'cache.tmp' (junk pattern)
INFO     | CLEAN complete: 3 removed, 0 errors

$ python file_automation.py sort --path ./sample_data
INFO     | Starting SORT on './sample_data' (8 file(s) found)
INFO     | Moved 'song.mp3' -> Audio/
INFO     | Moved 'beach.png' -> Images/
INFO     | Moved 'resume.docx' -> Documents/
INFO     | Moved 'archive.zip' -> Archives/
INFO     | Moved 'budget.xlsx' -> Spreadsheets/
INFO     | Moved 'notes.txt' -> Documents/
INFO     | Moved 'script.py' -> Code/
INFO     | Moved 'vacation.jpg' -> Images/
INFO     | SORT complete: 8 moved, 0 skipped, 0 errors

$ python file_automation.py rename --path ./sample_data/Documents --prefix doc_
INFO     | Starting RENAME on './sample_data/Documents' (2 file(s) found), prefix='doc_'
INFO     | Renamed 'notes.txt' -> 'doc_001.txt'
INFO     | Renamed 'resume.docx' -> 'doc_002.docx'
INFO     | RENAME complete: 2 renamed, 0 errors
```

## Sample Output (resulting structure)

```
sample_data/
├── Archives/archive.zip
├── Audio/song.mp3
├── Code/script.py
├── Documents/
│   ├── doc_001.txt
│   └── doc_002.docx
├── Images/
│   ├── beach.png
│   └── vacation.jpg
└── Spreadsheets/budget.xlsx
```

## Sample Log File (`file_automation.log`)

```
2026-07-01 05:57:17 | INFO     | Starting CLEAN on './sample_data' (11 file(s) found)
2026-07-01 05:57:17 | INFO     | Removed 'empty_placeholder.txt' (empty file)
2026-07-01 05:57:17 | INFO     | Removed 'old_run.log' (junk pattern)
2026-07-01 05:57:17 | INFO     | Removed 'cache.tmp' (junk pattern)
2026-07-01 05:57:17 | INFO     | CLEAN complete: 3 removed, 0 errors
2026-07-01 05:57:17 | INFO     | Starting SORT on './sample_data' (8 file(s) found)
2026-07-01 05:57:17 | INFO     | Moved 'song.mp3' -> Audio/
2026-07-01 05:57:17 | INFO     | SORT complete: 8 moved, 0 skipped, 0 errors
2026-07-01 05:57:18 | INFO     | Starting RENAME on './sample_data/Documents' (2 file(s) found), prefix='doc_'
2026-07-01 05:57:18 | INFO     | RENAME complete: 2 renamed, 0 errors
```

## Error Handling

The tool handles, without crashing:
- `FileNotFoundError` / `NotADirectoryError` — invalid target path
- `PermissionError` — insufficient OS permissions
- `FileExistsError` — rename target already taken
- Generic `OSError` — any other filesystem-level failure

All errors are logged at `ERROR` level with context; the tool then either
continues to the next file or exits cleanly with a non-zero status code.

## Project Structure

```
.
├── file_automation.py   # main script
├── README.md            # this file
└── sample_data/         # example input/output directory
```
